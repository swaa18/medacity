/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class storemail {
    public static String cemail;
    public static String demail;
    public static void store(String ce,String de)
    {
       cemail=ce;
       demail=de;
       System.out.println(cemail+demail);
    }
    public static String clientemail()
    {
            return cemail;
    }
    public static String doctoremail()
    {
            return demail;
    }
   
    
}
