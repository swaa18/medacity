/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author HP
 */
@WebServlet(urlPatterns = {"/broadcast"})
public class broadcast extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
          MongoClient client=new MongoClient(new MongoClientURI("mongodb://swap:1234@ds117739.mlab.com:17739/hospitalinfo"));
       DB database = client.getDB("hospitalinfo");
       DBCollection collection = database.getCollection("chathistory");
       
       
        String s="",s1="",message="";
       //database.collection.find({$and:[{"email":"tutorials point"}]});
       System.out.println("in");
         message=request.getParameter("broadcast");
       BasicDBObject whereQuery= new BasicDBObject();
      String clients="";
        storemail obj2=new storemail();
        //cemailretrieve obh=new cemailretrieve();
       whereQuery.put("demail",obj2.doctoremail());
      // whereQuery.put("cemail",obj2.clientemail());
       //whereQuery.put("cemail",clients);
       DBCursor cursor=collection.find(whereQuery);
       
       // System.out.println(database.collection.find({"fname":"Karan"});
       while(cursor.hasNext())
       {
           s="";
          s= cursor.next().get("message").toString();
          clients=cursor.curr().get("cemail").toString();
         // s2=cursor.curr().get("demail").toString();
         //  System.out.println(cursor.next().get("fname"));       
       
       BasicDBObject newdocument= new BasicDBObject();
      
       //whereQuery.put("demail",obj2.clientemail());
      // whereQuery.put("cemail",obj2.doctoremail());
      // DBCursor cursor=collection.find(whereQuery);
      
      s=s+'*'+message+'#';
      newdocument.append("$set",new BasicDBObject().append("message",s));
      BasicDBObject searchquery=new BasicDBObject().append("cemail", clients).append("demail", obj2.doctoremail());
      collection.update(searchquery, newdocument);
       
    }
       response.sendRedirect("chat1doctor.jsp");
    }
    
    }



