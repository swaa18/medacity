import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class BMI extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException
             {
                 Double weight=Double.parseDouble(request.getParameter("weight"));
                 Double height=Double.parseDouble(request.getParameter("height"));
                 height=height/100;
                 
                 Double bmi= (weight)/(height*height);
                 String b=bmi.toString();
                 b=b.substring(0, 5);
                 String status=" ";
                 if(bmi>40)
                 {
                    status="Very severely obese" ;
                 }
                 else if(bmi>35)
                 {
                    status="Severely obese" ; 
                 }
                 else if(bmi>30)
                 {
                     status="Moderately obese" ;
                 }
                 else if(bmi>25)
                 {
                     status="Overweight" ;
                 }
                 else if(bmi>18.5)
                 {
                     status="Normal" ;
                 }
                 else if(bmi>16)
                 {
                     status="Underweight" ;
                 }
                 else if(bmi>15)
                 {
                     status="Severely underweight" ;
                 }
                 else
                 {
                     status="Very severely underweight" ;
                 }
                 
                 HttpSession session =request.getSession();
                session.setAttribute("bmi", b);
                session.setAttribute("status", status);
                response.sendRedirect("bmi.jsp");
                
    }
}