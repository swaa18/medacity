//import javax.swing.text.Document;
import java.io.IOException;  
import org.jsoup.Jsoup;  
import org.jsoup.nodes.Document; 
import org.jsoup.select.Elements;
import org.jsoup.nodes.Element;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class crawlingp {
    String url2="https://www.practo.com/noida/neurosurgeon";
    String tip;
    Document doc;

    public crawlingp() throws IOException {
        this.doc = Jsoup.connect(url2).get();
    }
    public void crawling()
    {
    //Elements values=doc.select("[class=DoctorName__name___2fjjE]");
     Elements values1=doc.select("[class=c-card-info]").select("[class=u-title-font u-c-pointer u-bold]");        
     Elements values2=doc.select("[class=c-card-info]").select("[data-qa-id=practice_locality]");        
     Elements values3=doc.select("[class=c-card-info]").select("[data-qa-id=consultation_fee]"); 
     Elements values4=doc.select("[class=c-card-info]").select("[data-qa-id=doctor_experience]"); 
     Elements values5=doc.select("[class=c-card-info]").select("[data-qa-id=doctor_specialisation]");
   int c=0;
     for(Element name:values1)
      { 
        if(c==7)
            break;
       Element address=values2.get(c);
       Element fee=values3.get(c);
       Element experience=values4.get(c);
       Element specs=values5.get(c);
       System.out.println(""+name.text()+"\n"+address.text()+"\n"+fee.text()+"\n"+experience.text()+"\n"+specs.text()+"\n\n\n\n");
       c++;
      }
    }
    public void typo()
    {
        System.out.println("hi");
    }
    public static void main(String args[]) throws IOException
    {
        crawlingp obj=new crawlingp();
       // obj.typo();
        obj.crawling();
        //return;
    }
}
