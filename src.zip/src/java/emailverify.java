
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class emailverify {
   
    public String doctorInfoRetrive(String to,String from)
    {
         MongoClient client=new MongoClient(new MongoClientURI("mongodb://swap:1234@ds117739.mlab.com:17739/hospitalinfo"));
       DB database = client.getDB("hospitalinfo");
       DBCollection collection = database.getCollection("chathistory");
       String s="";
       //database.collection.find({$and:[{"email":"tutorials point"}]});
       System.out.println("in");
         BasicDBObject fields= new BasicDBObject();
       BasicDBObject whereQuery= new BasicDBObject();
       whereQuery.put("demail",to);
       whereQuery.put("cemail",from);
       DBCursor cursor=collection.find(whereQuery);
       
       // System.out.println(database.collection.find({"fname":"Karan"});
       if(cursor.hasNext())
       {
          s= cursor.next().get("message").toString();
         // s2=cursor.curr().get("demail").toString();
         //  System.out.println(cursor.next().get("fname"));
       }   
        else
       {
            DBObject obj2=new BasicDBObject("cemail",from)
               .append("demail",to).append("message","");
         collection.insert(obj2);
       }
       return s;
    }
    public void appendmessage(String message)
    {
          MongoClient client=new MongoClient(new MongoClientURI("mongodb://swap:1234@ds117739.mlab.com:17739/hospitalinfo"));
       DB database = client.getDB("hospitalinfo");
       DBCollection collection = database.getCollection("chathistory");
       
       
        String s="";
       //database.collection.find({$and:[{"email":"tutorials point"}]});
       System.out.println("in");
         
       BasicDBObject whereQuery= new BasicDBObject();
      String clients="";
        storemail obj2=new storemail();
        cemailretrieve obh=new cemailretrieve();
       whereQuery.put("demail",obj2.doctoremail());
      if(obj2.clientemail()!=null)
          clients=obj2.clientemail();
      
      
           else
      {clients=obh.getcemail();
      }
      // whereQuery.put("cemail",obj2.clientemail());
       whereQuery.put("cemail",clients);
       DBCursor cursor=collection.find(whereQuery);
       
       // System.out.println(database.collection.find({"fname":"Karan"});
       if(cursor.hasNext())
       {
          s= cursor.next().get("message").toString();
         // s2=cursor.curr().get("demail").toString();
         //  System.out.println(cursor.next().get("fname"));
       }        
       
       
       BasicDBObject newdocument= new BasicDBObject();
      
       //whereQuery.put("demail",obj2.clientemail());
      // whereQuery.put("cemail",obj2.doctoremail());
      // DBCursor cursor=collection.find(whereQuery);
      storemail st= new storemail();
      if(st.clientemail()==null)
      {
          s=s+'*'+message+'#';
      }
      else
      {
      s=s+'$'+message+'#';
      }
      System.out.println(s);
      newdocument.append("$set",new BasicDBObject().append("message",s));
      BasicDBObject searchquery=new BasicDBObject().append("cemail", clients).append("demail", obj2.doctoremail());
      collection.update(searchquery, newdocument);
       
    }
}

