
//import javax.swing.text.Document;
import java.io.IOException;  
import org.jsoup.Jsoup;  
import org.jsoup.nodes.Document; 
import org.jsoup.select.Elements;
import org.jsoup.nodes.Element;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class crawl {
    String url="https://www.1mg.com/doctors/heart-specialists-in-new-delhi/SPC-lzgx7";
    String tip;
    Document doc;

    public crawl() throws IOException {
        this.doc = Jsoup.connect(url).get();
    }
    public void crawling()
    {
    //Elements values=doc.select("[class=DoctorName__name___2fjjE]");
   Elements values=doc.select("[class=hide-on-med-and-down]");
       // Elements values2=values.select("[class=t-doctor-listing-profile-selected]");
       Elements values2=values.select("[style=width:38px;height:20px;border-radius:2px;background-color:#1aab2a;font-size:10px;color:#fff;margin-right:4px;float:left;display:inline-block;padding:2px 6px;font-weight:700;]");
       int c=0;      
       for(Element value:values2)
      { 
          c++;
          if(c%2==1)
       System.out.println(""+value.select("span").first().text());
      }
    }
    public void typo()
    {
        System.out.println("hi");
    }
    public static void main(String args[]) throws IOException
    {
        crawl obj=new crawl();
        obj.typo();
        obj.crawling();
        //return;
    }
}


