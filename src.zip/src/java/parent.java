/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class parent {
     public static String fname;
     public static String lname;
     public static String address;
     public static String pnumber;
     public static String email;
     public static String pass;
      public void addelement(String fnam,String lnam,String addres,String pnumbe,String emai,String pas)
      {
          fname=fnam;
          lname=lnam;
          address=addres;
          pnumber=pnumbe;
          email=emai;
          pass=pas;   
      }
      public String firstname()
      {
          return fname;
      }
      public String lastname()
      {
          return lname;
      }
      public String address()
      {
          return address;
      }
      public String phone()
      {
          return pnumber;
      }
      public String emai()
      {
          return email;
      }
      public String password()
      {
          return pass;
      }
     
}
