
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 * 
 */
import java.io.*;
public class trigger {
    /*
    public static void main(String args[]) throws IOException
    {
    String prg = "import sys";
BufferedWriter out = new BufferedWriter(new FileWriter("C:/Users/HP/Desktop/minor2/diseaseprediction/Predicting-Diseases-From-Symptoms-master/run.ipynb"));
out.write(prg);
out.close();
Process p = Runtime.getRuntime().exec("python C:/Users/HP/Desktop/minor2/diseaseprediction/Predicting-Diseases-From-Symptoms-master/run.ipynb");
BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
String ret = in.readLine();
System.out.println("value is : "+ret);
    } 
*/
 
public static void main(String a[]) throws IOException{
//try{
 
/*String prg = "import sys \nprint(int(sys.argv[1])+int(sys.argv[2]))";
BufferedWriter out = new BufferedWriter(new FileWriter("C:/Users/HP/Desktop/test1.py"));
out.write(prg);
out.close();
int number1 = 10;
int number2 = 32;
*/
//Process p = Runtime.getRuntime().exec("C:\\Users\\HP\\Desktop\\test1.py");

/*BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
int ret = new Integer(in.readLine()).intValue();
System.out.println("value is : "+ret);*/
//}catch(Exception e){}

String pythonScriptPath = "C:\\Users\\HP\\Desktop\\minor2\\diseaseprediction\\Predicting-Diseases-From-Symptoms-master\\diseaseprdiction.py";
String[] cmd = new String[2];
cmd[0] = "python"; // check version of installed python: python -V
cmd[1] = pythonScriptPath;
 
// create runtime to execute external command
Runtime rt = Runtime.getRuntime();
Process pr = rt.exec(cmd);
 
// retrieve output from python script

BufferedReader bfr = new BufferedReader(new InputStreamReader(pr.getInputStream()));
String line = "";
while((line = bfr.readLine()) != null) {
// display each output line form python script
System.out.println(line);
}
}
}
 
