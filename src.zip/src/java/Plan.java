/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
	import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
        import javax.servlet.http.HttpServletResponse;
	abstract class Plan{  
	         protected double rate;  
	         abstract void getRate(HttpServletResponse res);  
	   
	         public void calculateBill(int units){  
	              System.out.println(units*rate);  
	          }  
	}
	class  DomesticPlan extends Plan{  
        //@override  
        // public void getRate(){  
        //     rate=3.50;              
       // } 
         
         @Override
         public void getRate(HttpServletResponse res){
             try {
                 // here type your JSP page that you want to open
                 res.sendRedirect("crawling.jsp");
             } catch (IOException ex) {
                 Logger.getLogger(DomesticPlan.class.getName()).log(Level.SEVERE, null, ex);
             }
    }
   }
	class  CommercialPlan extends Plan{  
		   //@override   
		    public void getRate(HttpServletResponse res){   
		        rate=7.50;  
		   } 
	}
        class  InstitutionalPlan extends Plan{  
		    	   //@override  
		    public void getRate(HttpServletResponse res){   
		    	        rate=5.50;  
		    	   } 
	}
        
