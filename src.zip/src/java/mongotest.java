
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class mongotest {
    

public static void main(String ars[])
{
  System.out.println("in");
       MongoClient client=new MongoClient(new MongoClientURI("mongodb://swap:1234@ds117739.mlab.com:17739/hospitalinfo"));
       DB database = client.getDB("hospitalinfo");
       DBCollection collection = database.getCollection("information");
       
       //database.collection.find({$and:[{"email":"tutorials point"}]});
       System.out.println("in");
         BasicDBObject fields= new BasicDBObject();
       BasicDBObject whereQuery= new BasicDBObject();
       whereQuery.put("fname","Karan");
       whereQuery.put("lname","Singh");
       fields.put("fname",1);
       fields.put("lname",1);
       DBCursor cursor=collection.find(whereQuery,fields);
        String s="",s2="";
       // System.out.println(database.collection.find({"fname":"Karan"});
       while(cursor.hasNext())
       {
          s= cursor.next().get("fname").toString();
          s2=cursor.curr().get("lname").toString();
         //  System.out.println(cursor.next().get("fname"));
       }   
        System.out.println(s+s2);
}

}