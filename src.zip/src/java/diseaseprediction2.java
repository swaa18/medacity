
import java.io.File;
import java.io.IOException;
import net.sf.javaml.core.Dataset;
import net.sf.javaml.tools.data.FileHandler;


import net.sf.javaml.classification.Classifier;
import net.sf.javaml.classification.KNearestNeighbors;
import net.sf.javaml.core.AbstractInstance;
import net.sf.javaml.core.DenseInstance;
import net.sf.javaml.core.Instance;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class diseaseprediction2 {
    
    public static void main(String args[]) throws IOException
    {
        Dataset data =  FileHandler.loadSparseDataset(new File("C:/Users/HP/Desktop/minor2/diseaseprediction/Predicting-Diseases-From-Symptoms-master/Scraped-Data/df_pivoted.csv"), 0);
        Classifier knn = new KNearestNeighbors(10);
knn.buildClassifier(data);

  int correct = 0, wrong = 0;
        /* Classify all instances and check with the correct class values */
       for (Instance inst : data) {
          Object predictedClassValue = knn.classify(inst);
            Object realClassValue = inst.classValue();
     //       if (predictedClassValue.equals(realClassValue))
     //           correct++;
     ////       else
     //          wrong++; 
     //System.out.println(predictedClassValue); 
      System.out.println(realClassValue);
      }
    //   System.out.println("Correct predictions  " + correct);
     //   System.out.println("Wrong predictions " + wrong); 
       
        System.out.println(data);
        String[] s2=new String[]{"vomiting","choke"};
        Instance instance=new ;
        String s=knn.classify(instance);

    }
    }
