
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class disawt {
    public void main() throws IOException
    {
     
    Scanner scn=new Scanner(System.in);  
    System.out.println("ente disease");
    String s=scn.next();
    FileWriter fp=new FileWriter("test_file");
    //exec('python C:/Users/HP/Desktop/minor2/diseaseprediction/Predicting-Diseases-From-Symptoms-master');
    
    
}
}  