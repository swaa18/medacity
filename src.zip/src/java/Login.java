
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author HP
 */
public class Login extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       PrintWriter out=response.getWriter();
       String email=request.getParameter("email");
      
       String pass=request.getParameter("pass");
       MongoClient client=new MongoClient(new MongoClientURI("mongodb://swap:1234@ds117739.mlab.com:17739/hospitalinfo"));
       DB database = client.getDB("hospitalinfo");
       DBCollection collection = database.getCollection("information");
      // DBObject obj=new BasicDBObject("username",name)
      //         .append("password",pass);
      // collection.insert(obj);
      //database.info.find({"username":name});
      
      DBCollection collection2 = database.getCollection("informationdoctor");
      // DBObject obj=new BasicDBObject("username",name)
      //         .append("password",pass);
      // collection.insert(obj);
      //database.info.find({"username":name});
      
      
      BasicDBObject wherequerry= new BasicDBObject();
      wherequerry.put("email", email);
      wherequerry.put("pass", pass);
       DBCursor cursor1 = collection.find(wherequerry);
      DBCursor cursor2 = collection2.find(wherequerry);
     // out.print(cursor2.next());
      if(cursor2.hasNext())
      {
          storemail obj= new storemail();
       obj.store(null, email); 
       HttpSession session=request.getSession();
                session.setAttribute("username",email);
               // response.sendRedirect("welcome.jsp");
               response.sendRedirect("welcome.jsp");
      }
      else if(cursor1.hasNext() )
      {storemail obj= new storemail();
       obj.store(email,null); 
           HttpSession session=request.getSession();
                session.setAttribute("username",email);
               // response.sendRedirect("welcome.jsp");
               response.sendRedirect("welcome.jsp");
        }
      else
      {
          
          
              out.print("wrong username");
         // if(!cursor2.hasNext())
         //    out.print("wrong password");
         // response.sendRedirect("docOrClient.jsp");
        
      }
    }
        
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
