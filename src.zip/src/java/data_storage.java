/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Rishabh
 */
@WebServlet(urlPatterns = {"/data_storage"})
public class data_storage extends HttpServlet {

    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          HttpSession session=request.getSession();  
        String p=(String)session.getAttribute("prod");
       
        
        
        //abc obj=new abc();
        //String uemail=obj.getclientemail();
        
         MongoClient client=new MongoClient(new MongoClientURI("mongodb://swap:1234@ds117739.mlab.com:17739/hospitalinfo"));
               DB database = client.getDB("hospitalinfo");
                DBCollection collection = database.getCollection("cart");
                
                BasicDBObject document = new BasicDBObject();
                 storemail obj=new storemail();
                 document.put("pid", p);
                 document.put("uid",obj.clientemail());
                 collection.insert(document);
        
       response.sendRedirect("main.jsp");
                
    }


}
