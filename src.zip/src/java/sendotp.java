/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author HP
 */
public class sendotp extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try {
			// Construct data
                 String fname=request.getParameter("fname");
                 String lname=request.getParameter("lname");
                 String pnumber=request.getParameter("pnumber");
                 String address=request.getParameter("address");
                 String email=request.getParameter("email");
                 String pass=request.getParameter("pass");
                     
                        HttpSession session=request.getSession();
                        session.setAttribute("fname", fname);
                        session.setAttribute("lname", lname);
                        session.setAttribute("pnumber", pnumber);
                        session.setAttribute("address",address);
                        session.setAttribute("email", email);
                        session.setAttribute("pass", pass);
                        
                        parent obj=new parent();
                        obj.addelement(fname, lname, address, pnumber, email, pass);
			String apiKey = "apikey=" + URLEncoder.encode("j17mVJ983Zo-ZPom5bmYrR9mAEzl2t93xixzSrzng4", "UTF-8");
                        Random rand = new Random();
                       int otp = rand.nextInt(900000) + 100000;
                        //session.setAttribute("otp","900");
                        //int otp=0;
                        String otp2="";
                        otp2=otp2+otp;
                       // otp2=otp2+otp;
			String message = "&message=" + URLEncoder.encode("Your one time password is"+otp, "UTF-8");
			String sender = "&sender=" + URLEncoder.encode("TXTLCL", "UTF-8");
                        // pnumber=request.getParameter("pnumber");
                        pnumber="91"+pnumber;
			String numbers = "&numbers=" + URLEncoder.encode(pnumber, "UTF-8");
			
			// Send data
			String data = "https://api.textlocal.in/send/?" + apiKey + numbers + message + sender;
			URL url = new URL(data);
			URLConnection conn = url.openConnection();
			conn.setDoOutput(true);
			
			// Get the response
			BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			String sResult="";
			while ((line = rd.readLine()) != null) {
			// Process line...
				sResult=sResult+line+" ";
			}
			rd.close();
                        parenti obj3=new parenti();
                        obj3.added(otp2);
			
		} catch (Exception e) {
			System.out.println("Error SMS "+e);
		}
            response.sendRedirect("otpverification.jsp");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
