/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class parenti {
    public static String otp;

    void added(String ot) {
       // throw new UnsupportedOperationException("Not supported yet.");
        otp=(String)ot;//To change body of generated methods, choose Tools | Templates.
    }
    public String returnotp()
    {
        return otp;
    }
            
}
